/**
 * PlayerController — manual physics (no Rapier/WASM)
 * Gravity, ground check, wall collision all done in JS.
 */
import { useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { useGameStore } from '../systems/gameStore'
import { PLAYER, C } from '../config/gameConfig'
import { Katana } from '../weapons/Katana'
import { useCombatSystem, playerPosRef, playerFwdRef } from '../combat/CombatSystem'

// Arena bounds
const ARENA = 20

// Platform definitions [x, y, z, halfW, halfD]
const PLATFORMS = [
  [0,    0,   0,    22, 22],   // main floor (y=0 top surface)
  [12,   3.5, -8,   4.5, 4.5],
  [-14,  2.5,  6,   3.5, 3.5],
  [0,    5.5, -18,  5.5, 3.0],
  [-6,   8.0, -12,  3.0, 3.0],
]

function getGroundY(x, z) {
  let highest = -999
  for (const [px, py, pz, hw, hd] of PLATFORMS) {
    if (Math.abs(x - px) <= hw && Math.abs(z - pz) <= hd) {
      if (py > highest) highest = py
    }
  }
  return highest === -999 ? -999 : highest + PLAYER.GROUND_Y
}

export function PlayerController() {
  const groupRef = useRef()
  const meshRef  = useRef()
  const katanaRef= useRef()
  const { camera } = useThree()

  const pos     = useRef(new THREE.Vector3(0, 2, 0))
  const vel     = useRef(new THREE.Vector3())
  const yaw     = useRef(Math.PI)
  const pitch   = useRef(-0.2)
  const jumps   = useRef(0)
  const onGround= useRef(false)
  const dashing = useRef(false)
  const dashT   = useRef(0)
  const dashDir = useRef(new THREE.Vector3())
  const dashCD  = useRef(0)
  const charges = useRef(PLAYER.DASH_CHARGES)
  const sliding = useRef(false)
  const slideT  = useRef(0)
  const slideDir= useRef(new THREE.Vector3())
  const camPos  = useRef(new THREE.Vector3(0,4,8))
  const pk      = useRef({})

  const { attack, doParry, energyWave, finisher, isAtk, parry } = useCombatSystem()

  useFrame((_, delta) => {
    const gs = useGameStore.getState()
    if (gs.phase !== 'playing') return

    const slowF = gs.combat.isSlowMotion ? 0.22 : 1
    const dt = delta * slowF
    const keys = gs.keys

    // Mouse look
    const md = gs.mouseDelta
    if (md.x !== 0 || md.y !== 0) {
      yaw.current   -= md.x
      pitch.current  = Math.max(-0.5, Math.min(0.3, pitch.current - md.y))
      gs.setMouseDelta(0, 0)
    }

    // Dash cooldown / charge regen
    if (dashCD.current > 0) {
      dashCD.current -= delta
      if (dashCD.current <= 0 && charges.current < PLAYER.DASH_CHARGES) charges.current++
    }
    gs.setCombat({ dashCharges: charges.current })

    // Build input dir
    const inputDir = new THREE.Vector3()
    if (keys.forward)  inputDir.z -= 1
    if (keys.backward) inputDir.z += 1
    if (keys.left)     inputDir.x -= 1
    if (keys.right)    inputDir.x += 1
    const moving = inputDir.lengthSq() > 0
    if (moving) inputDir.normalize()
    const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, yaw.current, 0))
    inputDir.applyQuaternion(q)

    // Slide start
    if (keys.slide && keys.sprint && onGround.current && !sliding.current && moving) {
      sliding.current = true; slideT.current = PLAYER.SLIDE_DURATION
      slideDir.current.copy(inputDir)
    }
    if (sliding.current) { slideT.current -= dt; if (slideT.current <= 0) sliding.current = false }

    // Dash start
    if (keys.dash && !pk.current.dash && charges.current > 0 && !dashing.current) {
      dashing.current = true; dashT.current = PLAYER.DASH_DURATION
      charges.current--; dashCD.current = PLAYER.DASH_COOLDOWN
      dashDir.current.copy(moving ? inputDir : new THREE.Vector3(-Math.sin(yaw.current), 0, -Math.cos(yaw.current)))
      dashDir.current.y = 0; dashDir.current.normalize()
      vel.current.set(dashDir.current.x * PLAYER.DASH_SPEED, 0, dashDir.current.z * PLAYER.DASH_SPEED)
    }

    if (dashing.current) {
      dashT.current -= dt
      if (dashT.current <= 0) { dashing.current = false }
      else {
        vel.current.x = dashDir.current.x * PLAYER.DASH_SPEED
        vel.current.z = dashDir.current.z * PLAYER.DASH_SPEED
        if (keys.attack && !pk.current.attack) attack('dash')
      }
    } else {
      // Normal XZ movement
      const speed = sliding.current ? PLAYER.SLIDE_SPEED : keys.sprint ? PLAYER.SPRINT_SPEED : PLAYER.MOVE_SPEED
      const dir   = sliding.current ? slideDir.current : inputDir
      const accel = onGround.current ? 14 : 4
      vel.current.x = THREE.MathUtils.lerp(vel.current.x, moving ? dir.x * speed : 0, dt * accel)
      vel.current.z = THREE.MathUtils.lerp(vel.current.z, moving ? dir.z * speed : 0, dt * accel)
    }

    // Gravity
    if (!onGround.current) vel.current.y += PLAYER.GRAVITY * dt

    // Jump
    if (keys.jump && !pk.current.jump && jumps.current < 2) {
      const f = jumps.current === 0 ? PLAYER.JUMP_FORCE : PLAYER.DOUBLE_JUMP_FORCE
      vel.current.y = f; jumps.current++; onGround.current = false
    }

    // Move
    pos.current.addScaledVector(vel.current, dt)

    // Arena boundary clamp
    pos.current.x = Math.max(-ARENA, Math.min(ARENA, pos.current.x))
    pos.current.z = Math.max(-ARENA, Math.min(ARENA, pos.current.z))

    // Ground check
    const groundY = getGroundY(pos.current.x, pos.current.z)
    if (pos.current.y <= groundY) {
      pos.current.y = groundY
      if (vel.current.y < 0) { vel.current.y = 0; onGround.current = true; jumps.current = 0 }
    } else {
      onGround.current = false
    }

    // Rotate mesh
    if (meshRef.current && (moving || sliding.current)) {
      const dir = sliding.current ? slideDir.current : inputDir
      meshRef.current.rotation.y = THREE.MathUtils.lerp(meshRef.current.rotation.y, Math.atan2(dir.x, dir.z), dt * 12)
    }

    // Forward ref
    playerFwdRef.current.set(-Math.sin(yaw.current), 0, -Math.cos(yaw.current))
    playerPosRef.current.copy(pos.current)

    // Apply to scene group
    if (groupRef.current) groupRef.current.position.copy(pos.current)

    // Combat inputs
    if (keys.attack && !pk.current.attack)   attack('light')
    if (keys.heavy  && !pk.current.heavy)    attack('heavy')
    if (keys.parry  && !pk.current.parry)    doParry()
    if (keys.finisher && !pk.current.finisher) finisher()
    if (keys.energyWave && !pk.current.energyWave) energyWave()

    pk.current = { ...keys }

    // Camera spring follow
    const camD = PLAYER.CAMERA_DISTANCE
    const camH = PLAYER.CAMERA_HEIGHT + (sliding.current ? -0.8 : 0)
    const desired = new THREE.Vector3(
      pos.current.x + Math.sin(yaw.current) * camD,
      pos.current.y + camH + Math.sin(pitch.current) * camD * 0.5,
      pos.current.z + Math.cos(yaw.current) * camD
    )
    camPos.current.lerp(desired, Math.min(1, dt * 8))
    camera.position.copy(camPos.current)
    camera.lookAt(pos.current.x, pos.current.y + 1.1, pos.current.z)
  })

  const atkType = useGameStore(s => s.combat.attackType)
  const isAttacking = useGameStore(s => s.combat.isAttacking)

  return (
    <group ref={groupRef} position={[0,2,0]}>
      <group ref={meshRef}>
        {/* Torso */}
        <mesh position={[0,0.5,0]} castShadow>
          <capsuleGeometry args={[0.3,0.9,4,8]}/>
          <meshStandardMaterial color="#080816" metalness={0.75} roughness={0.25} emissive={C.CYAN} emissiveIntensity={0.07}/>
        </mesh>
        {/* Shoulder pads */}
        {[-0.36,0.36].map((x,i) => (
          <mesh key={i} position={[x,0.78,0]} castShadow>
            <boxGeometry args={[0.18,0.13,0.22]}/>
            <meshStandardMaterial color="#0d0d22" metalness={0.9} roughness={0.2} emissive={C.CYAN} emissiveIntensity={0.15}/>
          </mesh>
        ))}
        {/* Head */}
        <mesh position={[0,1.28,0]} castShadow>
          <sphereGeometry args={[0.21,10,10]}/>
          <meshStandardMaterial color="#0a0a1e" metalness={0.7} roughness={0.3}/>
        </mesh>
        {/* Visor */}
        <mesh position={[0,1.28,0.18]}>
          <boxGeometry args={[0.32,0.07,0.02]}/>
          <meshBasicMaterial color={C.CYAN} blending={THREE.AdditiveBlending} depthWrite={false}/>
        </mesh>
        {/* Chest stripe */}
        <mesh position={[0,0.58,0.3]}>
          <boxGeometry args={[0.42,0.035,0.01]}/>
          <meshBasicMaterial color={C.CYAN} blending={THREE.AdditiveBlending} depthWrite={false}/>
        </mesh>
        {/* Legs */}
        {[-0.14,0.14].map((x,i) => (
          <mesh key={i} position={[x,-0.18,0]} castShadow>
            <capsuleGeometry args={[0.11,0.52,4,6]}/>
            <meshStandardMaterial color="#060612" metalness={0.6} roughness={0.4}/>
          </mesh>
        ))}
        {/* Leg stripes */}
        {[-0.14,0.14].map((x,i) => (
          <mesh key={i} position={[x,-0.04,0.12]}>
            <boxGeometry args={[0.025,0.48,0.01]}/>
            <meshBasicMaterial color={C.CYAN} blending={THREE.AdditiveBlending} depthWrite={false}/>
          </mesh>
        ))}
        {/* Katana */}
        <group position={[0.38,0.78,-0.08]} rotation={[0.1,0,-0.25]}>
          <Katana ref={katanaRef} isAttacking={isAttacking} attackType={atkType}/>
        </group>
        {/* Body glow */}
        <pointLight color={C.CYAN} intensity={isAttacking ? 3 : 0.8} distance={5} decay={2}/>
        {/* Dash ghost */}
        {dashing.current && (
          <mesh position={[0,0.5,0]}>
            <capsuleGeometry args={[0.3,0.9,4,8]}/>
            <meshBasicMaterial color={C.CYAN} transparent opacity={0.15} blending={THREE.AdditiveBlending} depthWrite={false}/>
          </mesh>
        )}
      </group>
    </group>
  )
}

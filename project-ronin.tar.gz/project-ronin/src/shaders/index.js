/**
 * PROJECT RONIN — Rain Shader
 * Custom GLSL shaders for animated rain effect.
 * Uses time-based UV scrolling and depth-aware fading.
 */

export const rainVertexShader = /* glsl */`
  uniform float uTime;
  uniform float uSpeed;
  
  attribute float aOffset;
  attribute float aLength;
  attribute float aOpacity;
  
  varying float vOpacity;
  varying vec2 vUv;
  
  void main() {
    vOpacity = aOpacity;
    vUv = uv;
    
    // Animate rain falling downward with per-drop offset
    vec3 pos = position;
    float t = mod(uTime * uSpeed + aOffset, 1.0);
    pos.y -= t * 40.0;
    pos.y = mod(pos.y + 20.0, 40.0) - 20.0;
    
    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    gl_PointSize = 1.5;
  }
`

export const rainFragmentShader = /* glsl */`
  varying float vOpacity;
  varying vec2 vUv;
  
  void main() {
    // Streak shape: elongated along Y
    float alpha = vOpacity * (1.0 - vUv.y * 0.5);
    gl_FragColor = vec4(0.6, 0.8, 1.0, alpha * 0.4);
  }
`

// ─── Neon Glow Shader ─────────────────────────────────────────────────────────
export const neonGlowVertexShader = /* glsl */`
  varying vec3 vNormal;
  varying vec3 vPosition;
  
  void main() {
    vNormal = normalize(normalMatrix * normal);
    vPosition = (modelViewMatrix * vec4(position, 1.0)).xyz;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`

export const neonGlowFragmentShader = /* glsl */`
  uniform vec3 uColor;
  uniform float uIntensity;
  uniform float uTime;
  
  varying vec3 vNormal;
  varying vec3 vPosition;
  
  void main() {
    // Rim glow effect — brighter at silhouette edges
    vec3 viewDir = normalize(-vPosition);
    float rim = 1.0 - max(dot(vNormal, viewDir), 0.0);
    rim = pow(rim, 2.0);
    
    // Pulse animation
    float pulse = sin(uTime * 3.0) * 0.15 + 0.85;
    
    vec3 finalColor = uColor * uIntensity * rim * pulse;
    float alpha = rim * 0.8;
    
    gl_FragColor = vec4(finalColor, alpha);
  }
`

// ─── Hologram Shader ──────────────────────────────────────────────────────────
export const hologramVertexShader = /* glsl */`
  uniform float uTime;
  varying vec2 vUv;
  varying vec3 vNormal;
  
  void main() {
    vUv = uv;
    vNormal = normalize(normalMatrix * normal);
    
    // Subtle vertex jitter for hologram flicker
    vec3 pos = position;
    pos.x += sin(pos.y * 10.0 + uTime * 5.0) * 0.005;
    
    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
  }
`

export const hologramFragmentShader = /* glsl */`
  uniform float uTime;
  uniform vec3 uColor;
  
  varying vec2 vUv;
  varying vec3 vNormal;
  
  void main() {
    // Scanline effect
    float scanline = sin(vUv.y * 200.0 + uTime * 2.0) * 0.5 + 0.5;
    scanline = pow(scanline, 4.0);
    
    // Flicker
    float flicker = sin(uTime * 30.0) * 0.05 + 0.95;
    
    // Edge glow
    vec3 viewDir = normalize(cameraPosition - vNormal);
    float rim = 1.0 - abs(dot(vNormal, vec3(0.0, 0.0, 1.0)));
    
    float alpha = (0.3 + scanline * 0.2 + rim * 0.4) * flicker;
    vec3 color = uColor + uColor * scanline * 0.5;
    
    gl_FragColor = vec4(color, alpha * 0.85);
  }
`

// ─── Energy Slash Trail Shader ────────────────────────────────────────────────
export const slashTrailVertexShader = /* glsl */`
  attribute float aProgress;
  varying float vProgress;
  varying vec2 vUv;
  
  void main() {
    vProgress = aProgress;
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`

export const slashTrailFragmentShader = /* glsl */`
  uniform vec3 uColor;
  uniform float uTime;
  
  varying float vProgress;
  varying vec2 vUv;
  
  void main() {
    // Fade along the trail length
    float alpha = (1.0 - vProgress) * (1.0 - abs(vUv.y - 0.5) * 2.0);
    
    // Core bright + outer glow color
    vec3 core = vec3(1.0, 1.0, 1.0);
    vec3 finalColor = mix(uColor, core, pow(alpha, 3.0));
    
    gl_FragColor = vec4(finalColor, alpha * 0.9);
  }
`

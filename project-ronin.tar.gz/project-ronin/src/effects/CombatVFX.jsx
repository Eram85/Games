import { useGameStore } from '../systems/gameStore'
import { C } from '../config/gameConfig'

export function SlowMotionFX() {
  const isSlowMo = useGameStore(s => s.combat.isSlowMotion)
  if (!isSlowMo) return null
  return (
    <div style={{
      position:'fixed',inset:0,pointerEvents:'none',zIndex:50,
      border:'3px solid rgba(170,68,255,0.3)',
      boxShadow:'inset 0 0 80px rgba(170,68,255,0.12)',
    }}>
      <div style={{
        position:'absolute',bottom:50,left:'50%',transform:'translateX(-50%)',
        color:C.PLASMA,fontFamily:'Courier New',fontSize:11,letterSpacing:'0.4em',
        textShadow:`0 0 12px ${C.PLASMA}`,textTransform:'uppercase',
      }}>◆ BLADE TIME ◆</div>
    </div>
  )
}

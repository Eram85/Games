import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { GFX } from '../config/gameConfig'

export function RainSystem({ count = GFX.RAIN_COUNT, area = 55, height = 38 }) {
  const pts = useRef()
  const { positions, speeds } = useMemo(() => {
    const positions = new Float32Array(count * 3)
    const speeds    = new Float32Array(count)
    for (let i = 0; i < count; i++) {
      positions[i*3]   = (Math.random()-0.5)*area
      positions[i*3+1] = (Math.random()-0.5)*height
      positions[i*3+2] = (Math.random()-0.5)*area
      speeds[i] = 14 + Math.random()*10
    }
    return { positions, speeds }
  }, [count, area, height])

  useFrame((_, delta) => {
    if (!pts.current) return
    const arr = pts.current.geometry.attributes.position.array
    for (let i = 0; i < count; i++) {
      arr[i*3+1] -= speeds[i] * delta
      if (arr[i*3+1] < -height/2) {
        arr[i*3+1] = height/2
        arr[i*3]   = (Math.random()-0.5)*area
        arr[i*3+2] = (Math.random()-0.5)*area
      }
    }
    pts.current.geometry.attributes.position.needsUpdate = true
  })

  return (
    <points ref={pts}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={count} array={positions} itemSize={3}/>
      </bufferGeometry>
      <pointsMaterial color="#88aaff" size={0.06} transparent opacity={0.4} sizeAttenuation blending={THREE.AdditiveBlending} depthWrite={false}/>
    </points>
  )
}

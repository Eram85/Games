export const PLAYER = {
  MOVE_SPEED: 8, SPRINT_SPEED: 14,
  JUMP_FORCE: 12, DOUBLE_JUMP_FORCE: 10,
  GRAVITY: -28,
  DASH_SPEED: 22, DASH_DURATION: 0.15, DASH_COOLDOWN: 0.85, DASH_CHARGES: 2,
  SLIDE_SPEED: 15, SLIDE_DURATION: 0.6,
  GROUND_Y: 0.9,
  CAMERA_DISTANCE: 6, CAMERA_HEIGHT: 2.5,
}
export const COMBAT = {
  LIGHT_DAMAGE: 22, HEAVY_DAMAGE: 48, DASH_DAMAGE: 28,
  ENERGY_WAVE_DAMAGE: 60, FINISHER_DAMAGE: 140,
  LIGHT_DURATION: 0.22, HEAVY_DURATION: 0.48,
  COMBO_WINDOW: 0.7, STUN_DURATION: 2.0,
  ENERGY_WAVE_ENERGY: 28, SLOW_MOTION_ENERGY: 38,
  SLASH_RANGE: 2.5, HEAVY_RANGE: 3.2, WAVE_RANGE: 16,
}
export const ENEMY_DEFS = {
  soldier: { health:80,  damage:10, speed:3.8, reward:100, color:'#0a1830', accent:'#0088ff', scale:1.0 },
  ninja:   { health:55,  damage:18, speed:7.5, reward:200, color:'#1a0828', accent:'#ff00ff', scale:0.9, canParry:true },
  drone:   { health:35,  damage:8,  speed:6.0, reward:150, color:'#201000', accent:'#ff6600', scale:0.65, flying:true },
  mech:    { health:300, damage:30, speed:2.2, reward:500, color:'#111118', accent:'#00ff88', scale:1.6 },
}
export const C = {
  CYAN:'#00ffff', MAGENTA:'#ff00ff', ORANGE:'#ff6600',
  GREEN:'#00ff88', BLUE:'#0088ff', RED:'#ff2244',
  PLASMA:'#aa44ff', YELLOW:'#ffee00',
}
export const GFX = {
  BLOOM_INTENSITY: 1.5, BLOOM_THRESHOLD: 0.32,
  RAIN_COUNT: 2000,
}

import { create } from 'zustand'
import { subscribeWithSelector } from 'zustand/middleware'

const DEF_PLAYER = { health:100,maxHealth:100,energy:100,maxEnergy:100,score:0,combo:0,comboTimer:0,kills:0 }
const DEF_COMBAT = { isAttacking:false,attackType:'none',attackCombo:0,isParrying:false,isSlowMotion:false,slowMotionTimer:0,dashCharges:2,maxDashCharges:2 }

export const useGameStore = create(subscribeWithSelector((set,get) => ({
  phase: 'menu',
  setPhase: (p) => set({ phase: p }),

  player: { ...DEF_PLAYER },
  damagePlayer: (n) => set(s => {
    const health = Math.max(0, s.player.health - n)
    return { player: { ...s.player, health }, phase: health <= 0 ? 'gameover' : s.phase }
  }),
  useEnergy: (n) => {
    if (get().player.energy < n) return false
    set(s => ({ player: { ...s.player, energy: Math.max(0, s.player.energy - n) } }))
    return true
  },
  regenEnergy: (n) => set(s => ({ player: { ...s.player, energy: Math.min(s.player.maxEnergy, s.player.energy + n) } })),
  addScore: (pts) => set(s => ({ player: { ...s.player, score: s.player.score + pts * Math.max(1, s.player.combo) } })),
  addKill: () => set(s => ({ player: { ...s.player, kills: s.player.kills + 1 } })),
  incrementCombo: () => set(s => ({ player: { ...s.player, combo: s.player.combo + 1, comboTimer: 3 } })),
  tickComboTimer: (dt) => set(s => {
    const t = s.player.comboTimer - dt
    if (t <= 0 && s.player.combo > 0) return { player: { ...s.player, combo: 0, comboTimer: 0 } }
    return { player: { ...s.player, comboTimer: Math.max(0, t) } }
  }),

  combat: { ...DEF_COMBAT },
  setCombat: (p) => set(s => ({ combat: { ...s.combat, ...p } })),
  startSlowMotion: () => set(s => ({ combat: { ...s.combat, isSlowMotion: true, slowMotionTimer: 2.5 } })),
  tickSlowMotion: (dt) => set(s => {
    const t = s.combat.slowMotionTimer - dt
    return { combat: { ...s.combat, slowMotionTimer: Math.max(0, t), isSlowMotion: t > 0 } }
  }),

  enemies: [],
  addEnemy: (e) => set(s => ({ enemies: [...s.enemies, e] })),
  removeEnemy: (id) => set(s => ({ enemies: s.enemies.filter(e => e.id !== id) })),
  damageEnemy: (id, dmg) => set(s => ({ enemies: s.enemies.map(e => e.id === id ? { ...e, health: Math.max(0, e.health - dmg) } : e) })),
  updateEnemyState: (id, p) => set(s => ({ enemies: s.enemies.map(e => e.id === id ? { ...e, ...p } : e) })),

  keys: {},
  setKey: (k, v) => set(s => ({ keys: { ...s.keys, [k]: v } })),
  mouseDelta: { x: 0, y: 0 },
  setMouseDelta: (x, y) => set({ mouseDelta: { x, y } }),

  waveNumber: 1,
  nextWave: () => set(s => ({ waveNumber: s.waveNumber + 1, enemies: [] })),

  settings: { showFPS: false, graphicsQuality: 'high' },
  updateSettings: (p) => set(s => ({ settings: { ...s.settings, ...p } })),

  resetGame: () => set({
    phase: 'playing', enemies: [], waveNumber: 1,
    player: { ...DEF_PLAYER }, combat: { ...DEF_COMBAT },
  }),
})))

import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { EffectComposer, Bloom, ChromaticAberration, Vignette, SMAA, Noise } from '@react-three/postprocessing'
import { BlendFunction } from 'postprocessing'
import { Vector2 } from 'three'
import { useGameStore } from '../systems/gameStore'
import { GFX } from '../config/gameConfig'

export function PostProcessing() {
  const bloomRef = useRef(), caRef = useRef()
  const slowMo = useGameStore(s => s.combat.isSlowMotion)
  const atk    = useGameStore(s => s.combat.isAttacking)

  useFrame(() => {
    if (bloomRef.current) {
      const tgt = slowMo ? GFX.BLOOM_INTENSITY*2.2 : atk ? GFX.BLOOM_INTENSITY*1.5 : GFX.BLOOM_INTENSITY
      bloomRef.current.intensity += (tgt - bloomRef.current.intensity) * 0.1
    }
    if (caRef.current) {
      const tgt = slowMo ? 0.007 : atk ? 0.003 : 0.001
      caRef.current.offset.lerp(new Vector2(tgt, tgt), 0.1)
    }
  })

  return (
    <EffectComposer multisampling={0}>
      <SMAA/>
      <Bloom ref={bloomRef} intensity={GFX.BLOOM_INTENSITY} luminanceThreshold={GFX.BLOOM_THRESHOLD}
        luminanceSmoothing={0.85} mipmapBlur levels={7} radius={0.8}/>
      <ChromaticAberration ref={caRef} blendFunction={BlendFunction.NORMAL} offset={new Vector2(0.001,0.001)}/>
      <Noise blendFunction={BlendFunction.OVERLAY} opacity={0.04}/>
      <Vignette offset={0.3} darkness={slowMo?0.85:0.6}/>
    </EffectComposer>
  )
}

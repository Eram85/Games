import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { C } from '../config/gameConfig'
import { useGameStore } from '../systems/gameStore'

export function CyberpunkLighting() {
  const n1  = useRef(), n2 = useRef(), flash = useRef()
  const t   = useRef(0)
  const isAtk = useGameStore(s => s.combat.isAttacking)

  useFrame((_, delta) => {
    t.current += delta
    if (n1.current)    n1.current.intensity    = 1.2 + Math.sin(t.current*2.3)*0.25
    if (n2.current)    n2.current.intensity    = 0.8 + Math.sin(t.current*3.7+1.2)*0.2
    if (flash.current) flash.current.intensity = THREE.MathUtils.lerp(flash.current.intensity, isAtk?3.5:0, delta*20)
  })

  return (
    <>
      <ambientLight intensity={0.1} color="#0a0a1a"/>
      <directionalLight position={[10,30,10]} intensity={0.3} color="#1a1a3a" castShadow
        shadow-mapSize={[2048,2048]}
        shadow-camera-near={0.5} shadow-camera-far={100}
        shadow-camera-left={-40} shadow-camera-right={40}
        shadow-camera-top={40} shadow-camera-bottom={-40}
        shadow-bias={-0.001}/>
      <pointLight ref={n1} position={[0,12,0]}   color={C.CYAN}    intensity={1.2} distance={42} decay={1.5}/>
      <pointLight ref={n2} position={[-15,6,-5]}  color={C.MAGENTA} intensity={0.8} distance={30} decay={2}/>
      <pointLight position={[14,5,8]}   color={C.ORANGE}  intensity={0.6} distance={24} decay={2}/>
      <pointLight position={[0,4,-18]}  color={C.BLUE}    intensity={0.7} distance={26} decay={2}/>
      <pointLight position={[-8,3,12]}  color={C.GREEN}   intensity={0.4} distance={18} decay={2}/>
      <pointLight position={[0,0.4,0]}  color={C.CYAN}    intensity={0.25} distance={16} decay={2}/>
      <pointLight ref={flash} position={[0,2,0]} color={C.CYAN} intensity={0} distance={10} decay={2}/>
      <hemisphereLight skyColor="#000820" groundColor="#020208" intensity={0.3}/>
      <fogExp2 attach="fog" color="#000510" density={0.013}/>
    </>
  )
}

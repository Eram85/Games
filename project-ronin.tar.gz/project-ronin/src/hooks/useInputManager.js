import { useEffect } from 'react'
import { useGameStore } from '../systems/gameStore'

const KEYS = {
  KeyW:'forward', KeyS:'backward', KeyA:'left', KeyD:'right',
  Space:'jump', ShiftLeft:'sprint', ShiftRight:'sprint',
  KeyC:'slide', KeyF:'finisher', KeyR:'energyWave', KeyG:'parry', Escape:'pause',
}

export function useInputManager() {
  useEffect(() => {
    const { setKey, setMouseDelta } = useGameStore.getState()
    const kd = (e) => { if (e.code === 'Space') e.preventDefault(); const a = KEYS[e.code]; if (a) setKey(a, true) }
    const ku = (e) => { const a = KEYS[e.code]; if (a) setKey(a, false) }
    const md = (e) => { if (e.button===0) setKey('attack',true); if (e.button===2) setKey('heavy',true); if (e.button===1) setKey('dash',true) }
    const mu = (e) => { if (e.button===0) setKey('attack',false); if (e.button===2) setKey('heavy',false); if (e.button===1) setKey('dash',false) }
    const mm = (e) => { if (document.pointerLockElement) setMouseDelta(e.movementX * 0.003, e.movementY * 0.002) }
    const cx = (e) => e.preventDefault()
    window.addEventListener('keydown', kd)
    window.addEventListener('keyup', ku)
    window.addEventListener('mousedown', md)
    window.addEventListener('mouseup', mu)
    window.addEventListener('mousemove', mm)
    window.addEventListener('contextmenu', cx)
    return () => {
      window.removeEventListener('keydown', kd)
      window.removeEventListener('keyup', ku)
      window.removeEventListener('mousedown', md)
      window.removeEventListener('mouseup', mu)
      window.removeEventListener('mousemove', mm)
      window.removeEventListener('contextmenu', cx)
    }
  }, [])
}

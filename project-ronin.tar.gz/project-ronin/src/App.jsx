import { useGameStore } from './systems/gameStore'
import { GameScene } from './scenes/GameScene'
import { GameHUD } from './ui/GameHUD'
import { MainMenu, GameOverScreen, VictoryScreen } from './ui/MainMenu'
import { SlowMotionFX } from './effects/CombatVFX'
import { useInputManager } from './hooks/useInputManager'

export default function App() {
  const phase = useGameStore(s => s.phase)
  useInputManager()

  return (
    <div style={{ width:'100vw', height:'100vh', position:'relative', overflow:'hidden', background:'#000' }}>
      <GameScene/>
      {phase === 'playing'  && <><GameHUD/><SlowMotionFX/></>}
      {phase === 'menu'     && <MainMenu/>}
      {phase === 'gameover' && <><GameHUD/><GameOverScreen/></>}
      {phase === 'victory'  && <><GameHUD/><VictoryScreen/></>}
    </div>
  )
}

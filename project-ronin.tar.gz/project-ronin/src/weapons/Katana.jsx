import { useRef, forwardRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Trail } from '@react-three/drei'
import * as THREE from 'three'
import { C } from '../config/gameConfig'

export const Katana = forwardRef(function Katana({ isAttacking, attackType = 'light' }, ref) {
  const bladeRef = useRef()
  const tipRef   = useRef()
  const t = useRef(0)

  useFrame((_, delta) => {
    t.current += delta
    if (bladeRef.current?.material) {
      const base = isAttacking ? 2.5 : 0.7
      bladeRef.current.material.emissiveIntensity = base + Math.sin(t.current * 4) * 0.3
    }
  })

  const color = attackType === 'heavy' ? C.RED : attackType === 'finisher' ? C.PLASMA : C.CYAN

  return (
    <group>
      {/* Handle */}
      <mesh position={[0,-0.4,0]}>
        <cylinderGeometry args={[0.025,0.03,0.36,8]}/>
        <meshStandardMaterial color="#111128" metalness={0.8} roughness={0.4}/>
      </mesh>
      {/* Guard */}
      <mesh position={[0,-0.2,0]} rotation={[Math.PI/2,0,0]}>
        <torusGeometry args={[0.065,0.014,6,16]}/>
        <meshStandardMaterial color="#2a2a4a" metalness={0.9} roughness={0.15} emissive={color} emissiveIntensity={0.4}/>
      </mesh>
      {/* Blade */}
      <mesh ref={bladeRef} position={[0,0.52,0]}>
        <boxGeometry args={[0.015,1.05,0.004]}/>
        <meshStandardMaterial color="#c8d8f0" metalness={1} roughness={0.05} emissive={color} emissiveIntensity={0.7}/>
      </mesh>
      {/* Left edge */}
      <mesh position={[-0.009,0.52,0]}>
        <boxGeometry args={[0.003,1.06,0.001]}/>
        <meshBasicMaterial color={color} transparent opacity={0.9} blending={THREE.AdditiveBlending} depthWrite={false}/>
      </mesh>
      {/* Right edge */}
      <mesh position={[0.009,0.52,0]}>
        <boxGeometry args={[0.003,1.06,0.001]}/>
        <meshBasicMaterial color={color} transparent opacity={0.9} blending={THREE.AdditiveBlending} depthWrite={false}/>
      </mesh>
      {/* Tip anchor */}
      <mesh ref={tipRef} position={[0,1.08,0]} visible={false}>
        <sphereGeometry args={[0.01]}/><meshBasicMaterial/>
      </mesh>
      {/* Swing trail */}
      {isAttacking && (
        <Trail width={0.28} length={7} color={new THREE.Color(color)} attenuation={t => t*t*t} target={tipRef}>
          <mesh position={[0,1.08,0]} visible={false}><sphereGeometry args={[0.01]}/><meshBasicMaterial/></mesh>
        </Trail>
      )}
      <pointLight position={[0,0.5,0]} color={color} intensity={isAttacking ? 3.5 : 1.0} distance={3.5} decay={2}/>
    </group>
  )
})

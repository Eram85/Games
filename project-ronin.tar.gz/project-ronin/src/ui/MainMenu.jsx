import { useState, useEffect } from 'react'
import { useGameStore } from '../systems/gameStore'
import { C } from '../config/gameConfig'

export function MainMenu() {
  const setPhase = useGameStore(s => s.setPhase)
  const [glitch, setGlitch] = useState(false)
  useEffect(() => {
    const id = setInterval(() => { setGlitch(true); setTimeout(() => setGlitch(false), 80) }, 3200+Math.random()*1500)
    return () => clearInterval(id)
  }, [])

  return (
    <div style={{position:'fixed',inset:0,background:'#000005',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',fontFamily:'Courier New',overflow:'hidden',zIndex:200}}>
      {/* Grid */}
      <div style={{position:'absolute',inset:0,backgroundImage:`linear-gradient(rgba(0,255,255,0.025) 1px,transparent 1px),linear-gradient(90deg,rgba(0,255,255,0.025) 1px,transparent 1px)`,backgroundSize:'48px 48px',pointerEvents:'none'}}/>
      {/* Glow orbs */}
      {[['-15%','35%',C.CYAN],['110%','58%',C.MAGENTA],['50%','-5%',C.BLUE]].map(([l,t,c],i)=>(
        <div key={i} style={{position:'absolute',left:l,top:t,width:500,height:500,borderRadius:'50%',background:`radial-gradient(circle,${c}10 0%,transparent 70%)`,transform:'translate(-50%,-50%)',pointerEvents:'none'}}/>
      ))}
      <div style={{fontSize:10,color:C.MAGENTA,letterSpacing:'0.55em',textTransform:'uppercase',textShadow:`0 0 8px ${C.MAGENTA}`,marginBottom:18,opacity:0.8}}>CYBER BLADE CHRONICLES</div>
      {/* Title with glitch */}
      <div style={{position:'relative',marginBottom:8}}>
        <div style={{fontSize:'clamp(46px,7vw,86px)',fontWeight:900,letterSpacing:'0.15em',color:C.CYAN,textShadow:`0 0 20px ${C.CYAN},0 0 40px ${C.CYAN}55`,textTransform:'uppercase',transform:glitch?`translateX(${(Math.random()-0.5)*8}px)`:undefined}}>
          PROJECT RONIN
        </div>
        {glitch && <div style={{position:'absolute',top:0,left:0,fontSize:'clamp(46px,7vw,86px)',fontWeight:900,letterSpacing:'0.15em',color:C.RED,textTransform:'uppercase',opacity:0.5,transform:'translateX(5px)',pointerEvents:'none'}}>PROJECT RONIN</div>}
      </div>
      <div style={{width:210,height:1,background:`linear-gradient(90deg,transparent,${C.CYAN},transparent)`,margin:'20px 0',boxShadow:`0 0 10px ${C.CYAN}`}}/>
      {/* Buttons */}
      {[['▶  ENTER THE ARENA',()=>setPhase('playing'),true]].map(([label,fn,primary])=>(
        <button key={label} onClick={fn} style={{
          background:primary?`rgba(0,255,255,0.07)`:'transparent',
          border:`1px solid ${primary?C.CYAN:'#333'}`,color:primary?C.CYAN:'#555',
          fontFamily:'Courier New',fontSize:primary?14:11,letterSpacing:'0.25em',textTransform:'uppercase',
          padding:primary?'14px 52px':'10px 44px',cursor:'pointer',borderRadius:4,minWidth:260,
          display:'block',marginBottom:10,textShadow:primary?`0 0 10px ${C.CYAN}`:'none',
          boxShadow:primary?`0 0 22px rgba(0,255,255,0.12)`:'none',transition:'all 0.18s',
        }}
        onMouseEnter={e=>{e.currentTarget.style.background='rgba(0,255,255,0.14)';e.currentTarget.style.boxShadow=`0 0 30px rgba(0,255,255,0.28)`}}
        onMouseLeave={e=>{e.currentTarget.style.background=primary?'rgba(0,255,255,0.07)':'transparent';e.currentTarget.style.boxShadow=primary?'0 0 22px rgba(0,255,255,0.12)':'none'}}
        >{label}</button>
      ))}
      <div style={{position:'absolute',bottom:24,color:'#2a2a2a',fontSize:9,letterSpacing:'0.2em',textAlign:'center',lineHeight:2}}>
        CLICK CANVAS TO LOCK MOUSE • WASD MOVE • SPACE JUMP • LMB LIGHT • RMB HEAVY • MMB DASH<br/>
        R ENERGY WAVE • G PARRY • F FINISHER • SHIFT SPRINT • C+SHIFT SLIDE
      </div>
      {/* Corner frames */}
      {[{top:14,left:14},{top:14,right:14},{bottom:14,left:14},{bottom:14,right:14}].map((s,i)=>
        <div key={i} style={{position:'absolute',width:26,height:26,borderTop:i<2?`2px solid ${C.CYAN}44`:undefined,borderBottom:i>=2?`2px solid ${C.CYAN}44`:undefined,borderLeft:(i===0||i===2)?`2px solid ${C.CYAN}44`:undefined,borderRight:(i===1||i===3)?`2px solid ${C.CYAN}44`:undefined,...s}}/>
      )}
    </div>
  )
}

export function GameOverScreen() {
  const score = useGameStore(s => s.player.score)
  const kills = useGameStore(s => s.player.kills)
  const reset = useGameStore(s => s.resetGame)
  return (
    <div style={{position:'fixed',inset:0,zIndex:300,background:'rgba(0,0,0,0.88)',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',fontFamily:'Courier New'}}>
      <div style={{fontSize:58,color:C.RED,textShadow:`0 0 30px ${C.RED}`,letterSpacing:'0.1em',marginBottom:14}}>SYSTEM FAILURE</div>
      <div style={{color:'#444',fontSize:10,letterSpacing:'0.35em',marginBottom:5}}>FINAL SCORE</div>
      <div style={{color:C.CYAN,fontSize:38,textShadow:`0 0 14px ${C.CYAN}`,marginBottom:5}}>{String(score).padStart(8,'0')}</div>
      <div style={{color:'#333',fontSize:10,letterSpacing:'0.2em',marginBottom:38}}>KILLS: {kills}</div>
      <button onClick={reset} style={{background:'transparent',border:`1px solid ${C.RED}`,color:C.RED,fontFamily:'Courier New',fontSize:12,letterSpacing:'0.3em',padding:'12px 44px',cursor:'pointer',textShadow:`0 0 8px ${C.RED}`,textTransform:'uppercase',transition:'all 0.2s'}}
        onMouseEnter={e=>e.currentTarget.style.background='rgba(255,34,68,0.1)'}
        onMouseLeave={e=>e.currentTarget.style.background='transparent'}
      >RETRY MISSION</button>
    </div>
  )
}

export function VictoryScreen() {
  const score = useGameStore(s => s.player.score)
  const kills = useGameStore(s => s.player.kills)
  const reset = useGameStore(s => s.resetGame)
  return (
    <div style={{position:'fixed',inset:0,zIndex:300,background:'rgba(0,0,0,0.85)',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',fontFamily:'Courier New'}}>
      <div style={{fontSize:54,color:C.CYAN,textShadow:`0 0 30px ${C.CYAN}`,letterSpacing:'0.12em',marginBottom:14}}>MISSION CLEAR</div>
      <div style={{color:'#444',fontSize:10,letterSpacing:'0.35em',marginBottom:5}}>FINAL SCORE</div>
      <div style={{color:C.CYAN,fontSize:38,textShadow:`0 0 14px ${C.CYAN}`,marginBottom:5}}>{String(score).padStart(8,'0')}</div>
      <div style={{color:'#333',fontSize:10,letterSpacing:'0.2em',marginBottom:38}}>KILLS: {kills}</div>
      <button onClick={reset} style={{background:'transparent',border:`1px solid ${C.CYAN}`,color:C.CYAN,fontFamily:'Courier New',fontSize:12,letterSpacing:'0.3em',padding:'12px 44px',cursor:'pointer',textShadow:`0 0 8px ${C.CYAN}`,textTransform:'uppercase',transition:'all 0.2s'}}
        onMouseEnter={e=>e.currentTarget.style.background='rgba(0,255,255,0.08)'}
        onMouseLeave={e=>e.currentTarget.style.background='transparent'}
      >PLAY AGAIN</button>
    </div>
  )
}

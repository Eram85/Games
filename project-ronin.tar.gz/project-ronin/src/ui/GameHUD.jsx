import { useGameStore } from '../systems/gameStore'
import { C } from '../config/gameConfig'

function Bar({ value, max, color, label }) {
  const pct = Math.max(0, Math.min(1, value/max))
  const low  = pct < 0.25
  return (
    <div style={{marginBottom:9}}>
      <div style={{fontSize:9,color:'#555',fontFamily:'Courier New',letterSpacing:'0.2em',marginBottom:3,textTransform:'uppercase'}}>{label}</div>
      <div style={{width:210,height:6,background:'rgba(255,255,255,0.07)',borderRadius:3,overflow:'hidden'}}>
        <div style={{width:`${pct*100}%`,height:'100%',background:low?`linear-gradient(90deg,${C.RED},#ff6666)`:`linear-gradient(90deg,${color}88,${color})`,borderRadius:3,transition:'width 0.08s',boxShadow:`0 0 8px ${low?C.RED:color}`}}/>
      </div>
      <div style={{fontSize:9,color:low?C.RED:color,fontFamily:'Courier New',marginTop:2,textShadow:`0 0 6px ${color}`}}>{Math.ceil(value)}/{max}</div>
    </div>
  )
}

function DashPips({ charges, max }) {
  return (
    <div style={{display:'flex',gap:6,marginTop:4}}>
      {Array.from({length:max},(_,i)=>(
        <div key={i} style={{width:12,height:12,borderRadius:'50%',background:i<charges?C.CYAN:'rgba(255,255,255,0.07)',boxShadow:i<charges?`0 0 7px ${C.CYAN}`:'none',border:`1px solid ${i<charges?C.CYAN:'#333'}`,transition:'all 0.2s'}}/>
      ))}
    </div>
  )
}

function ComboCounter({ combo, comboTimer }) {
  if (combo < 2) return null
  const sz = Math.min(26+combo*1.8, 64)
  return (
    <div style={{position:'absolute',top:'38%',right:55,textAlign:'right',pointerEvents:'none'}}>
      <div style={{fontSize:sz,fontFamily:'Courier New',fontWeight:900,color:C.ORANGE,textShadow:`0 0 ${14+combo*2}px ${C.ORANGE},0 0 ${26+combo}px ${C.RED}`,lineHeight:1}}>{combo}</div>
      <div style={{fontSize:10,color:'#ff9944',fontFamily:'Courier New',letterSpacing:'0.25em',textTransform:'uppercase'}}>COMBO</div>
      <div style={{width:68,height:3,background:'rgba(255,255,255,0.08)',marginTop:4,marginLeft:'auto',borderRadius:2}}>
        <div style={{width:`${(comboTimer/3)*100}%`,height:'100%',background:C.ORANGE,borderRadius:2,boxShadow:`0 0 6px ${C.ORANGE}`,transition:'width 0.06s linear'}}/>
      </div>
    </div>
  )
}

function Crosshair({ isAtk, isPar, hasLock }) {
  const col = isPar?C.ORANGE:isAtk?C.RED:hasLock?C.RED:C.CYAN
  const g   = isAtk?14:10
  return (
    <div style={{position:'absolute',top:'50%',left:'50%',transform:'translate(-50%,-50%)',pointerEvents:'none'}}>
      {/* Lines */}
      {[
        {top:0,left:'50%',transform:'translateX(-50%)',width:'1.5px',height:g*0.4},
        {bottom:0,left:'50%',transform:'translateX(-50%)',width:'1.5px',height:g*0.4},
        {top:'50%',left:0,transform:'translateY(-50%)',height:'1.5px',width:g*0.4},
        {top:'50%',right:0,transform:'translateY(-50%)',height:'1.5px',width:g*0.4},
      ].map((s,i)=>(
        <div key={i} style={{position:'absolute',background:col,boxShadow:`0 0 5px ${col}`,...s}}/>
      ))}
      <div style={{position:'absolute',top:'50%',left:'50%',transform:'translate(-50%,-50%)',width:3,height:3,borderRadius:'50%',background:col,boxShadow:`0 0 7px ${col}`}}/>
      {hasLock && <div style={{position:'absolute',top:'50%',left:'50%',transform:'translate(-50%,-50%)',width:28,height:28,border:`1.5px solid ${C.RED}`,borderRadius:'50%',boxShadow:`0 0 10px ${C.RED}`,animation:'spin 2s linear infinite'}}/>}
    </div>
  )
}

function WaveBadge({ waveNumber }) {
  return (
    <div style={{position:'absolute',top:18,left:'50%',transform:'translateX(-50%)',color:C.CYAN,fontFamily:'Courier New',fontSize:10,letterSpacing:'0.35em',textShadow:`0 0 10px ${C.CYAN}`,textTransform:'uppercase',background:'rgba(0,0,0,0.42)',border:`1px solid rgba(0,255,255,0.14)`,padding:'5px 16px',borderRadius:4}}>
      ◆ WAVE {waveNumber}
    </div>
  )
}

function Controls() {
  const b = [['LMB','Attack'],['RMB','Heavy'],['MMB','Dash'],['R','Wave'],['G','Parry'],['F','Finisher'],['SPC×2','2×Jump'],['C+SH','Slide']]
  return (
    <div style={{position:'absolute',bottom:16,left:'50%',transform:'translateX(-50%)',display:'flex',gap:10,fontFamily:'Courier New'}}>
      {b.map(([k,a])=>(
        <div key={k} style={{textAlign:'center'}}>
          <div style={{fontSize:8,color:C.CYAN,background:'rgba(0,255,255,0.06)',border:`1px solid rgba(0,255,255,0.25)`,padding:'2px 5px',borderRadius:3,marginBottom:2}}>{k}</div>
          <div style={{fontSize:7,color:'#444'}}>{a}</div>
        </div>
      ))}
    </div>
  )
}

export function GameHUD() {
  const player = useGameStore(s => s.player)
  const combat = useGameStore(s => s.combat)
  const wave   = useGameStore(s => s.waveNumber)
  return (
    <div style={{position:'fixed',inset:0,pointerEvents:'none',zIndex:100,userSelect:'none'}}>
      {/* Stats */}
      <div style={{position:'absolute',top:16,left:16,background:'rgba(0,0,0,0.45)',backdropFilter:'blur(8px)',border:`1px solid rgba(0,255,255,0.1)`,borderRadius:8,padding:'11px 15px'}}>
        <div style={{fontSize:9,color:C.CYAN,letterSpacing:'0.35em',marginBottom:9,textShadow:`0 0 8px ${C.CYAN}`,textTransform:'uppercase'}}>◆ RONIN</div>
        <Bar value={player.health} max={player.maxHealth} color={C.CYAN}    label="VITALITY"/>
        <Bar value={player.energy} max={player.maxEnergy} color={C.MAGENTA} label="ENERGY"/>
        <div style={{fontSize:9,color:'#444',marginTop:5,letterSpacing:'0.2em',textTransform:'uppercase'}}>Dash</div>
        <DashPips charges={combat.dashCharges} max={combat.maxDashCharges}/>
      </div>
      {/* Score */}
      <div style={{position:'absolute',top:16,right:16,textAlign:'right',fontFamily:'Courier New'}}>
        <div style={{fontSize:22,color:C.CYAN,fontWeight:'bold',textShadow:`0 0 14px ${C.CYAN}`,letterSpacing:'0.04em'}}>{String(player.score).padStart(8,'0')}</div>
        <div style={{fontSize:9,color:'#444',letterSpacing:'0.25em',marginTop:2}}>KILLS: {player.kills}</div>
      </div>
      <WaveBadge waveNumber={wave}/>
      <ComboCounter combo={player.combo} comboTimer={player.comboTimer}/>
      <Crosshair isAtk={combat.isAttacking} isPar={combat.isParrying} hasLock={false}/>
      <Controls/>
      <style>{`@keyframes spin{from{transform:translate(-50%,-50%)rotate(0deg)}to{transform:translate(-50%,-50%)rotate(360deg)}}`}</style>
    </div>
  )
}

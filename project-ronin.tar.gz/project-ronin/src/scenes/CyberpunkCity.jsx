import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { C } from '../config/gameConfig'

function Building({ pos, w, h, d, accent }) {
  return (
    <group position={pos}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[w,h,d]}/>
        <meshStandardMaterial color="#070710" metalness={0.7} roughness={0.4}/>
      </mesh>
      {[[-w/2,0.02],[w/2,-0.02]].map(([x],i)=>(
        <mesh key={i} position={[x,0,0]}>
          <boxGeometry args={[0.04,h+0.1,d+0.06]}/>
          <meshBasicMaterial color={accent} transparent opacity={0.7} blending={THREE.AdditiveBlending} depthWrite={false}/>
        </mesh>
      ))}
      <mesh position={[0,h/2+0.05,0]}>
        <boxGeometry args={[w+0.1,0.1,d+0.1]}/>
        <meshBasicMaterial color={accent} transparent opacity={0.55} blending={THREE.AdditiveBlending} depthWrite={false}/>
      </mesh>
      <pointLight position={[0,h/2+1,0]} color={accent} intensity={0.7} distance={8} decay={2}/>
    </group>
  )
}

function HoloBillboard({ pos, h, color }) {
  const ref = useRef(); const t = useRef(0)
  useFrame((_,d)=>{ t.current+=d; if(ref.current) ref.current.material.opacity=0.5+Math.sin(t.current*2.5)*0.12 })
  return (
    <group position={pos}>
      <mesh position={[0,h/2,0]}>
        <cylinderGeometry args={[0.07,0.09,h,6]}/>
        <meshStandardMaterial color="#111128" metalness={0.9} roughness={0.2}/>
      </mesh>
      <mesh ref={ref} position={[0,h+1.1,0]}>
        <planeGeometry args={[3,1.8]}/>
        <meshBasicMaterial color={color} transparent opacity={0.52} blending={THREE.AdditiveBlending} depthWrite={false} side={THREE.DoubleSide}/>
      </mesh>
      <pointLight position={[0,h+1.1,0]} color={color} intensity={1.0} distance={7} decay={2}/>
    </group>
  )
}

function Platform({ pos, w, d, color='#050510' }) {
  const h = 0.4
  return (
    <group position={pos}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[w,h,d]}/>
        <meshStandardMaterial color={color} metalness={0.92} roughness={0.12}/>
      </mesh>
      {/* Grid lines */}
      {[-w/2,0,w/2].map((x,i)=>(
        <mesh key={i} position={[x,h/2+0.001,0]}>
          <planeGeometry args={[0.018,d]}/>
          <meshBasicMaterial color={C.CYAN} transparent opacity={0.1} blending={THREE.AdditiveBlending} depthWrite={false}/>
        </mesh>
      ))}
      {[-d/2,0,d/2].map((z,i)=>(
        <mesh key={i} position={[0,h/2+0.001,z]} rotation={[0,Math.PI/2,0]}>
          <planeGeometry args={[0.018,w]}/>
          <meshBasicMaterial color={C.CYAN} transparent opacity={0.1} blending={THREE.AdditiveBlending} depthWrite={false}/>
        </mesh>
      ))}
    </group>
  )
}

export function CyberpunkCity() {
  return (
    <group>
      {/* Main floor */}
      <Platform pos={[0,0,0]} w={44} d={44}/>
      {/* Elevated platforms */}
      <Platform pos={[12,3.5,-8]}   w={9}  d={9}/>
      <Platform pos={[-14,2.5,6]}   w={7}  d={7}/>
      <Platform pos={[0,5.5,-18]}   w={11} d={6}/>
      <Platform pos={[-6,8,-12]}    w={6}  d={6}/>
      {/* Arena walls */}
      {[
        [[0,2.8,22],[44,5.5,0.6]],
        [[0,2.8,-22],[44,5.5,0.6]],
        [[22,2.8,0],[0.6,5.5,44]],
        [[-22,2.8,0],[0.6,5.5,44]],
      ].map(([p,s],i)=>(
        <mesh key={i} position={p} receiveShadow>
          <boxGeometry args={s}/>
          <meshStandardMaterial color="#080812" metalness={0.8} roughness={0.4}/>
        </mesh>
      ))}
      {/* Wall neon tubes */}
      {[[C.CYAN,0,3.9,22,44,false],[C.MAGENTA,0,3.9,-22,44,false],[C.BLUE,22,3.9,0,44,true],[C.ORANGE,-22,3.9,0,44,true]].map(([col,x,y,z,len,axis],i)=>(
        <mesh key={i} position={[x,y,z]}>
          <boxGeometry args={axis?[0.06,0.06,len]:[len,0.06,0.06]}/>
          <meshBasicMaterial color={col} blending={THREE.AdditiveBlending} depthWrite={false}/>
        </mesh>
      ))}
      {/* Ground grid */}
      {[-15,-5,5,15].map((x,i)=>(
        <mesh key={`gv${i}`} position={[x,0.22,0]}>
          <boxGeometry args={[0.025,0.01,44]}/>
          <meshBasicMaterial color={C.CYAN} transparent opacity={0.15} blending={THREE.AdditiveBlending} depthWrite={false}/>
        </mesh>
      ))}
      {[-15,-5,5,15].map((z,i)=>(
        <mesh key={`gh${i}`} position={[0,0.22,z]}>
          <boxGeometry args={[44,0.01,0.025]}/>
          <meshBasicMaterial color={C.CYAN} transparent opacity={0.15} blending={THREE.AdditiveBlending} depthWrite={false}/>
        </mesh>
      ))}
      {/* Background skyscrapers */}
      <Building pos={[26,14,-22]} w={5} h={28} d={5} accent={C.CYAN}/>
      <Building pos={[-29,18,-16]} w={6} h={36} d={6} accent={C.MAGENTA}/>
      <Building pos={[19,10,-32]} w={4} h={20} d={4} accent={C.BLUE}/>
      <Building pos={[-21,8,-26]} w={7} h={16} d={5} accent={C.GREEN}/>
      <Building pos={[36,6,-10]} w={4} h={12} d={4} accent={C.ORANGE}/>
      <Building pos={[-36,10,-5]} w={5} h={20} d={5} accent={C.CYAN}/>
      <Building pos={[0,7,-43]} w={9} h={14} d={6} accent={C.MAGENTA}/>
      <Building pos={[28,5,20]} w={4} h={10} d={4} accent={C.PLASMA}/>
      {/* Holograms */}
      <HoloBillboard pos={[8,0,-12]} h={9} color={C.CYAN}/>
      <HoloBillboard pos={[-10,0,-8]} h={11} color={C.MAGENTA}/>
      <HoloBillboard pos={[16,3.5,-4]} h={7} color={C.ORANGE}/>
      {/* Distant city glow */}
      <mesh position={[0,5,-44]}>
        <planeGeometry args={[120,30]}/>
        <meshBasicMaterial color={C.CYAN} transparent opacity={0.022} blending={THREE.AdditiveBlending} depthWrite={false} side={THREE.DoubleSide}/>
      </mesh>
    </group>
  )
}

import { Suspense, useEffect } from 'react'
import { Canvas } from '@react-three/fiber'
import { AdaptiveDpr, Stats } from '@react-three/drei'
import { useGameStore } from '../systems/gameStore'
import { PlayerController } from '../player/PlayerController'
import { EnemyWave } from '../enemies/EnemyAI'
import { CyberpunkCity } from './CyberpunkCity'
import { CyberpunkLighting } from '../components/CyberpunkLighting'
import { PostProcessing } from '../components/PostProcessing'
import { RainSystem } from '../effects/RainSystem'

const WAVES = [
  [
    { id:'e1', type:'soldier',  spawnPosition:[8,1,-6] },
    { id:'e2', type:'soldier',  spawnPosition:[-7,1,-8] },
    { id:'e3', type:'soldier',  spawnPosition:[10,1,6] },
  ],
  [
    { id:'e4', type:'ninja',    spawnPosition:[9,1,-5] },
    { id:'e5', type:'soldier',  spawnPosition:[-9,1,5] },
    { id:'e6', type:'ninja',    spawnPosition:[1,1,-14] },
    { id:'e7', type:'soldier',  spawnPosition:[13,1,0] },
  ],
  [
    { id:'e8',  type:'drone',   spawnPosition:[0,6,-10] },
    { id:'e9',  type:'drone',   spawnPosition:[8,6,8] },
    { id:'e10', type:'mech',    spawnPosition:[-10,1,-4] },
    { id:'e11', type:'ninja',   spawnPosition:[5,1,11] },
    { id:'e12', type:'soldier', spawnPosition:[-5,1,11] },
  ],
]

function WaveManager() {
  const enemies  = useGameStore(s => s.enemies)
  const waveNum  = useGameStore(s => s.waveNumber)
  const nextWave = useGameStore(s => s.nextWave)
  const setPhase = useGameStore(s => s.setPhase)
  const phase    = useGameStore(s => s.phase)

  useEffect(() => {
    if (phase !== 'playing') return
    const wIdx = waveNum - 1
    if (enemies.length === 0 && WAVES[wIdx]) {
      const id = setTimeout(() => {
        if (waveNum < WAVES.length) nextWave()
        else setPhase('victory')
      }, 2000)
      return () => clearTimeout(id)
    }
  }, [enemies.length, waveNum, phase])

  if (phase !== 'playing') return null
  const current = WAVES[(waveNum-1)] || []
  return <EnemyWave enemies={current}/>
}

function GameWorld() {
  const showFPS = useGameStore(s => s.settings.showFPS)
  return (
    <>
      <CyberpunkLighting/>
      <PlayerController/>
      <WaveManager/>
      <CyberpunkCity/>
      <RainSystem/>
      <PostProcessing/>
      <AdaptiveDpr pixelSizes={[0.5,0.75,1]}/>
      {showFPS && <Stats/>}
    </>
  )
}

export function GameScene() {
  return (
    <Canvas
      shadows
      dpr={[1,1.5]}
      gl={{ antialias:false, powerPreference:'high-performance', alpha:false, stencil:false }}
      camera={{ fov:68, near:0.1, far:200 }}
      onCreated={({ gl }) => {
        gl.domElement.addEventListener('click', () => {
          if (useGameStore.getState().phase === 'playing') {
            gl.domElement.requestPointerLock()
          }
        })
      }}
    >
      <Suspense fallback={null}>
        <GameWorld/>
      </Suspense>
    </Canvas>
  )
}

/**
 * PROJECT RONIN — Audio Manager
 * Web Audio API-based sound system.
 * Handles positional 3D audio, music layers, and SFX pooling.
 *
 * STATUS: Architecture scaffolded. Plug in audio files to activate.
 * Add .mp3/.ogg files to /public/assets/audio/ and call loadSounds().
 */
export class AudioManager {
  constructor() {
    this.ctx = null
    this.masterGain = null
    this.sfxGain = null
    this.musicGain = null
    this.sounds = new Map()
    this.musicSource = null
  }

  async init() {
    this.ctx = new (window.AudioContext || window.webkitAudioContext)()
    this.masterGain = this.ctx.createGain()
    this.sfxGain = this.ctx.createGain()
    this.musicGain = this.ctx.createGain()

    this.sfxGain.connect(this.masterGain)
    this.musicGain.connect(this.masterGain)
    this.masterGain.connect(this.ctx.destination)

    this.masterGain.gain.value = 0.8
    this.sfxGain.gain.value = 1.0
    this.musicGain.gain.value = 0.5
  }

  async loadSound(name, url) {
    const response = await fetch(url)
    const buffer = await response.arrayBuffer()
    const decoded = await this.ctx.decodeAudioData(buffer)
    this.sounds.set(name, decoded)
  }

  play(name, { volume = 1, loop = false, positional = false, position = [0,0,0] } = {}) {
    if (!this.ctx || !this.sounds.has(name)) return

    const source = this.ctx.createBufferSource()
    source.buffer = this.sounds.get(name)
    source.loop = loop

    const gainNode = this.ctx.createGain()
    gainNode.gain.value = volume

    if (positional) {
      const panner = this.ctx.createPanner()
      panner.setPosition(...position)
      source.connect(panner)
      panner.connect(gainNode)
    } else {
      source.connect(gainNode)
    }

    gainNode.connect(this.sfxGain)
    source.start()
    return source
  }

  setMasterVolume(v) { this.masterGain.gain.value = v }
  setSFXVolume(v) { this.sfxGain.gain.value = v }
  setMusicVolume(v) { this.musicGain.gain.value = v }

  // Sound catalogue — add actual file paths when assets are ready
  static SOUNDS = {
    SLASH_LIGHT: '/assets/audio/slash_light.mp3',
    SLASH_HEAVY: '/assets/audio/slash_heavy.mp3',
    SLASH_AIR: '/assets/audio/slash_air.mp3',
    DASH: '/assets/audio/dash.mp3',
    PARRY: '/assets/audio/parry.mp3',
    PARRY_PERFECT: '/assets/audio/parry_perfect.mp3',
    ENERGY_WAVE: '/assets/audio/energy_wave.mp3',
    FINISHER: '/assets/audio/finisher.mp3',
    ENEMY_HIT: '/assets/audio/enemy_hit.mp3',
    ENEMY_DEATH: '/assets/audio/enemy_death.mp3',
    PLAYER_HIT: '/assets/audio/player_hit.mp3',
    FOOTSTEP: '/assets/audio/footstep.mp3',
    RAIN_AMBIENT: '/assets/audio/rain_ambient.mp3',
    MUSIC_COMBAT: '/assets/audio/music_combat.mp3',
    MUSIC_MENU: '/assets/audio/music_menu.mp3',
  }
}

// Singleton instance
export const audioManager = new AudioManager()

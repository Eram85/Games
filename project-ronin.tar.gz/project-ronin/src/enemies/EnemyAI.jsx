import { useRef, useEffect, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { useGameStore } from '../systems/gameStore'
import { ENEMY_DEFS, C } from '../config/gameConfig'
import { playerPosRef } from '../combat/CombatSystem'

const GROUND_Y = 0.9

function EnemyVisual({ type, hpPct, isStunned, isParrying }) {
  const def = ENEMY_DEFS[type] || ENEMY_DEFS.soldier
  const s   = def.scale
  const accent = isStunned ? '#ffffff' : isParrying ? C.ORANGE : def.accent
  const eI = isStunned ? 0.8 : isParrying ? 0.6 : 0.2

  return (
    <group scale={[s,s,s]}>
      <mesh position={[0,0.45,0]} castShadow>
        <capsuleGeometry args={[0.28,0.78,4,8]}/>
        <meshStandardMaterial color={def.color} metalness={0.8} roughness={0.3} emissive={accent} emissiveIntensity={eI}/>
      </mesh>
      <mesh position={[0,1.1,0]} castShadow>
        <sphereGeometry args={[0.19,8,8]}/>
        <meshStandardMaterial color={def.color} metalness={0.9} roughness={0.2}/>
      </mesh>
      {/* Visor */}
      <mesh position={[0,1.1,0.17]}>
        <boxGeometry args={[0.24,0.05,0.01]}/>
        <meshBasicMaterial color={accent} blending={THREE.AdditiveBlending} depthWrite={false}/>
      </mesh>
      {/* Drone rotors */}
      {type==='drone' && [[-0.32,0.4,0],[0.32,0.4,0],[0,0.4,-0.32],[0,0.4,0.32]].map((p,i)=>(
        <mesh key={i} position={p} rotation={[Math.PI/2,0,0]}>
          <torusGeometry args={[0.09,0.014,4,10]}/>
          <meshBasicMaterial color={C.ORANGE}/>
        </mesh>
      ))}
      {/* Mech cannons */}
      {type==='mech' && [-0.55,0.55].map((x,i)=>(
        <mesh key={i} position={[x,0.9,0.1]} rotation={[0.3,0,0]}>
          <cylinderGeometry args={[0.06,0.08,0.45,6]}/>
          <meshStandardMaterial color="#111" metalness={1} roughness={0.1}/>
        </mesh>
      ))}
      {/* HP bar */}
      {hpPct < 1 && (
        <group position={[0,1.8/s,0]}>
          <mesh><planeGeometry args={[0.7,0.07]}/><meshBasicMaterial color="#111" side={THREE.DoubleSide}/></mesh>
          <mesh position={[(hpPct-1)*0.35,0,0.001]}>
            <planeGeometry args={[0.7*hpPct,0.055]}/>
            <meshBasicMaterial color={hpPct>0.5?C.GREEN:hpPct>0.25?C.YELLOW:C.RED}/>
          </mesh>
        </group>
      )}
      <pointLight color={accent} intensity={0.4} distance={3} decay={2}/>
    </group>
  )
}

export function Enemy({ id, type='soldier', spawnPosition=[5,1,-5] }) {
  const def = ENEMY_DEFS[type] || ENEMY_DEFS.soldier
  const pos = useRef(new THREE.Vector3(...spawnPosition))
  const vel = useRef(new THREE.Vector3())
  const gRef= useRef()
  const state= useRef('patrol')
  const atkCD= useRef(Math.random()*0.5)
  const stunT= useRef(0)
  const parryT=useRef(0)
  const patrolAngle=useRef(Math.random()*Math.PI*2)
  const patrolT=useRef(0)
  const [hp, setHp]   = useState(def.health)
  const [dead, setDead]= useState(false)

  useEffect(() => {
    const s = useGameStore.getState()
    s.addEnemy({ id, type, health: def.health, maxHealth: def.health, pos: [...spawnPosition], state: 'patrol' })
    return () => s.removeEnemy(id)
  }, [id])

  useFrame((_, rawDelta) => {
    if (dead || !gRef.current) return
    const gs    = useGameStore.getState()
    const slowF = gs.combat.isSlowMotion ? 0.22 : 1
    const dt    = rawDelta * slowF

    const storeE = gs.enemies.find(e => e.id === id)
    if (!storeE) return

    // Death check
    if (storeE.health <= 0 && !dead) {
      setDead(true); gs.removeEnemy(id); gs.addKill(); gs.addScore(def.reward); return
    }
    setHp(storeE.health)

    // Sync stun
    if (storeE.state === 'stunned' && state.current !== 'stunned') {
      state.current = 'stunned'; stunT.current = storeE.stunLeft ?? 2
    }

    const pp = playerPosRef.current
    const dx = pp.x - pos.current.x, dz = pp.z - pos.current.z
    const dist = Math.sqrt(dx*dx+dz*dz)

    if (atkCD.current > 0) atkCD.current -= dt
    if (parryT.current > 0) parryT.current -= dt

    switch (state.current) {
      case 'patrol': {
        patrolT.current -= dt
        if (patrolT.current <= 0) { patrolAngle.current += (Math.random()-0.5)*2; patrolT.current = 2+Math.random() }
        const px = Math.cos(patrolAngle.current)*2.5, pz = Math.sin(patrolAngle.current)*2.5
        vel.current.x = THREE.MathUtils.lerp(vel.current.x, px, dt*3)
        vel.current.z = THREE.MathUtils.lerp(vel.current.z, pz, dt*3)
        if (dist < 14) state.current = 'chase'
        break
      }
      case 'chase': {
        if (dist < 1.8) { state.current='attack'; break }
        if (dist > 18)  { state.current='patrol'; break }
        const spd = def.speed
        vel.current.x = THREE.MathUtils.lerp(vel.current.x, (dx/dist)*spd, dt*5)
        vel.current.z = THREE.MathUtils.lerp(vel.current.z, (dz/dist)*spd, dt*5)
        break
      }
      case 'attack': {
        vel.current.x *= 0.8; vel.current.z *= 0.8
        if (dist > 2.8) { state.current='chase'; break }
        if (atkCD.current <= 0) {
          if (def.canParry && Math.random() < 0.2) {
            state.current = 'parrying'; parryT.current = 0.5
            gs.updateEnemyState(id, { state:'parrying' })
          } else {
            gs.damagePlayer(def.damage); atkCD.current = 1.3+Math.random()*0.5
          }
        }
        break
      }
      case 'parrying': {
        vel.current.x *= 0.8; vel.current.z *= 0.8
        if (parryT.current <= 0) { state.current='attack'; gs.updateEnemyState(id, { state:'attack' }) }
        break
      }
      case 'stunned': {
        vel.current.x *= 0.85; vel.current.z *= 0.85
        stunT.current -= dt
        if (stunT.current <= 0) { state.current='chase'; gs.updateEnemyState(id, { state:'chase' }) }
        break
      }
    }

    // Gravity & ground
    const flyY = def.flying ? spawnPosition[1]+2 : null
    if (def.flying) {
      vel.current.y = THREE.MathUtils.lerp(vel.current.y, (flyY - pos.current.y)*3, dt*4)
    } else {
      vel.current.y += -28 * dt
      if (pos.current.y <= GROUND_Y) { pos.current.y = GROUND_Y; vel.current.y = 0 }
    }

    pos.current.addScaledVector(vel.current, dt)

    // Arena bounds
    pos.current.x = Math.max(-19, Math.min(19, pos.current.x))
    pos.current.z = Math.max(-19, Math.min(19, pos.current.z))

    // Rotate to face player
    if (gRef.current && dist > 0.5) {
      gRef.current.rotation.y = THREE.MathUtils.lerp(gRef.current.rotation.y, Math.atan2(dx,dz), dt*8)
    }
    gRef.current.position.copy(pos.current)
    gs.updateEnemyState(id, { pos: [pos.current.x, pos.current.y, pos.current.z] })
  })

  if (dead) return null

  return (
    <group ref={gRef} position={[...spawnPosition]}>
      <EnemyVisual
        type={type}
        hpPct={hp/def.health}
        isStunned={state.current==='stunned'}
        isParrying={state.current==='parrying'}
      />
    </group>
  )
}

export function EnemyWave({ enemies }) {
  return <>{enemies.map(e => <Enemy key={e.id} id={e.id} type={e.type} spawnPosition={e.spawnPosition}/>)}</>
}

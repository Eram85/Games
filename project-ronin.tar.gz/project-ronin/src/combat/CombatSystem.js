import { useRef, useCallback } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { useGameStore } from '../systems/gameStore'
import { COMBAT } from '../config/gameConfig'

// Shared player world position — enemies read this
export const playerPosRef = { current: new THREE.Vector3() }
export const playerFwdRef = { current: new THREE.Vector3(0,0,-1) }

const COMBO = [
  { type:'light',    dmg: COMBAT.LIGHT_DAMAGE,    dur: COMBAT.LIGHT_DURATION },
  { type:'light',    dmg: COMBAT.LIGHT_DAMAGE*1.2, dur: COMBAT.LIGHT_DURATION },
  { type:'light',    dmg: COMBAT.LIGHT_DAMAGE*1.4, dur: COMBAT.LIGHT_DURATION },
  { type:'heavy',    dmg: COMBAT.HEAVY_DAMAGE,     dur: COMBAT.HEAVY_DURATION },
  { type:'finisher', dmg: COMBAT.FINISHER_DAMAGE,  dur: 0.7 },
]

function hitEnemies(dmg, type) {
  const s = useGameStore.getState()
  const p = playerPosRef.current
  const range = type === 'heavy' ? COMBAT.HEAVY_RANGE : COMBAT.SLASH_RANGE
  s.enemies.forEach(e => {
    if (!e.pos || e.state === 'dead') return
    const dx = e.pos[0]-p.x, dz = e.pos[2]-p.z
    if (Math.sqrt(dx*dx+dz*dz) > range) return
    if (e.state === 'parrying') return
    s.damageEnemy(e.id, dmg)
    s.updateEnemyState(e.id, { state:'stunned', stunLeft: COMBAT.STUN_DURATION })
    s.incrementCombo()
    s.addScore(dmg * 2)
  })
}

export function useCombatSystem() {
  const ci     = useRef(0)  // combo index
  const atkT   = useRef(0)  // attack timer
  const cWin   = useRef(0)  // combo window
  const isAtk  = useRef(false)
  const queued = useRef(false)
  const parry  = useRef(false)
  const parryT = useRef(0)

  const attack = useCallback((type = 'light') => {
    if (isAtk.current) { if (cWin.current > 0) queued.current = true; return }
    const def = type === 'heavy'
      ? { type:'heavy', dmg: COMBAT.HEAVY_DAMAGE, dur: COMBAT.HEAVY_DURATION }
      : type === 'dash'
      ? { type:'dash',  dmg: COMBAT.DASH_DAMAGE,  dur: 0.18 }
      : COMBO[ci.current] ?? COMBO[0]
    isAtk.current = true
    atkT.current  = def.dur
    cWin.current  = 0
    ci.current    = type === 'heavy' ? 0 : (ci.current + 1) % COMBO.length
    useGameStore.getState().setCombat({ isAttacking:true, attackType: def.type, attackCombo: ci.current })
    hitEnemies(def.dmg, def.type)
  }, [])

  const doParry = useCallback(() => {
    parry.current  = true
    parryT.current = 0.4
    useGameStore.getState().setCombat({ isParrying: true })
  }, [])

  const energyWave = useCallback(() => {
    const ok = useGameStore.getState().useEnergy(COMBAT.ENERGY_WAVE_ENERGY)
    if (!ok) return
    const s = useGameStore.getState()
    const p = playerPosRef.current, f = playerFwdRef.current
    s.enemies.forEach(e => {
      if (!e.pos) return
      const dx = e.pos[0]-p.x, dz = e.pos[2]-p.z
      const dist = Math.sqrt(dx*dx+dz*dz)
      if (dist > COMBAT.WAVE_RANGE) return
      const dot = dist > 0.01 ? (dx*f.x + dz*f.z) / dist : 1
      if (dot > 0.2) {
        s.damageEnemy(e.id, COMBAT.ENERGY_WAVE_DAMAGE)
        s.updateEnemyState(e.id, { state:'stunned', stunLeft: 2.5 })
        s.addScore(300)
      }
    })
  }, [])

  const finisher = useCallback(() => {
    const s = useGameStore.getState()
    if (!s.useEnergy(COMBAT.SLOW_MOTION_ENERGY)) return
    s.startSlowMotion()
    let closest = null, minD = Infinity
    s.enemies.forEach(e => {
      if (!e.pos) return
      const d = new THREE.Vector3(...e.pos).distanceTo(playerPosRef.current)
      if (d < minD) { minD = d; closest = e }
    })
    if (closest) { s.damageEnemy(closest.id, COMBAT.FINISHER_DAMAGE); s.addScore(2500); s.incrementCombo() }
  }, [])

  useFrame((_, delta) => {
    const s = useGameStore.getState()
    const dt = s.combat.isSlowMotion ? delta * 0.22 : delta
    if (isAtk.current) {
      atkT.current -= dt
      if (atkT.current <= 0) {
        isAtk.current = false; cWin.current = COMBAT.COMBO_WINDOW
        s.setCombat({ isAttacking: false, attackType: 'none' })
        if (queued.current) { queued.current = false; attack('light') }
      }
    }
    if (cWin.current > 0) { cWin.current -= dt; if (cWin.current <= 0) ci.current = 0 }
    if (parry.current) { parryT.current -= dt; if (parryT.current <= 0) { parry.current = false; s.setCombat({ isParrying: false }) } }
    s.tickSlowMotion(delta)
    s.tickComboTimer(delta)
    s.regenEnergy(10 * delta)
  })

  return { attack, doParry, energyWave, finisher, isAtk, parry }
}

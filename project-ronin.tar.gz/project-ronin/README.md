# ⚔️ PROJECT RONIN
### Futuristic Anime-Inspired Cyberpunk Sword Combat — Web Game

> Inspired by Ghostrunner · Metal Gear Rising · Cyberpunk 2077 · Devil May Cry 5

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev

# 3. Open browser
# Navigate to http://localhost:5173
# Click the canvas to lock mouse (enable camera look)
```

---

## 📁 Project Structure

```
project-ronin/
├── public/
│   └── assets/
│       ├── textures/       # PBR texture maps
│       ├── audio/          # SFX and music files
│       └── models/         # GLTF character/weapon models
│
└── src/
    ├── App.jsx             # Root: phase routing (menu → game → gameover)
    ├── main.jsx            # React entry point
    │
    ├── config/
    │   └── gameConfig.js   # All tunable game constants (speeds, damage, colors)
    │
    ├── systems/
    │   └── gameStore.js    # Zustand global state: player, combat, enemies, settings
    │
    ├── hooks/
    │   └── useInputManager.js   # Keyboard/mouse/gamepad input capture
    │
    ├── scenes/
    │   ├── GameScene.jsx   # Canvas setup + scene composition
    │   └── CyberpunkCity.jsx  # Environment: buildings, holograms, platforms
    │
    ├── player/
    │   └── PlayerController.jsx  # Movement, dash, jump, wall-run, slide
    │
    ├── enemies/
    │   └── EnemyAI.jsx     # State-machine AI: soldier, ninja, drone types
    │
    ├── combat/
    │   └── CombatSystem.js # Combo logic, hit resolution, parry, finishers
    │
    ├── weapons/
    │   └── Katana.jsx      # Blade geometry, neon glow, swing trail
    │
    ├── shaders/
    │   └── index.js        # GLSL: rain, hologram, neon glow, slash trail
    │
    ├── effects/
    │   ├── RainSystem.jsx  # 3000-particle rain using BufferGeometry
    │   └── CombatVFX.jsx  # Sparks, energy waves, death explosions
    │
    ├── components/
    │   ├── PostProcessing.jsx  # Bloom, chromatic aberration, vignette, SMAA
    │   └── CyberpunkLighting.jsx  # Multi-light neon atmosphere + fog
    │
    ├── physics/
    │   └── PhysicsWorld.jsx   # Rapier physics config + slow-mo time step
    │
    ├── ui/
    │   ├── GameHUD.jsx     # Health/energy bars, combo, score, crosshair
    │   └── MainMenu.jsx    # Animated title screen + game over screen
    │
    ├── audio/              # (Placeholder) Audio manager system
    └── utils/              # (Placeholder) Math helpers, pooling utilities
```

---

## 🎮 Controls

| Action | Key/Button |
|--------|-----------|
| Move | WASD |
| Sprint | Hold Shift |
| Jump / Double Jump | Space (press twice) |
| Dash | Middle Mouse Button |
| Slide | C (while sprinting) |
| Light Attack | Left Mouse Button |
| Heavy Attack | Right Mouse Button |
| Energy Wave | R |
| Parry | G |
| Finisher (Slow-Mo) | F |
| Lock-On | Q |
| Pause | Escape / Tab |
| Camera Look | Mouse (click canvas first to lock) |

---

## ⚙️ Core Systems

### 🗡️ Combo System
The combat chain supports 5-hit combos:
- **Hits 1–3**: Light slashes (increasing damage multiplier)
- **Hit 4**: Heavy finisher slam
- **Hit 5**: Cinematic finisher (100 damage)

Chain window: **0.6 seconds** between hits. Miss the window → combo resets.

### 🏃 Movement
- Ground move speed: **8 m/s** (14 sprinting)
- Dash: **15 m/s** burst for 0.15s, 2 charges, 0.8s cooldown each
- Gravity: **18 m/s²** for snappy feel
- Physics: Rapier WASM rigid body with capsule collider

### 🤖 Enemy AI States
```
PATROL → (detect) → DETECT → CHASE → ATTACK
         ↑____________________________|
                                      ↓
                                  STUNNED → CHASE
                                      ↓
                                    DEAD
```

### ⚡ Energy System
- Passive regen: **8/s**
- Energy Wave costs: **30**
- Slow-Motion Finisher costs: **40**
- Dash Attack costs: **10**

---

## 🎨 Visual Pipeline

```
Three.js Scene
    ↓
SMAA Anti-aliasing
    ↓
Tone Mapping (ACES Filmic)
    ↓
Bloom (mipmap, radius 0.85, intensity 1.8)   ← Dynamic during combat
    ↓
Chromatic Aberration                          ← Pulses during slow-mo
    ↓
Depth of Field (Ultra mode only)
    ↓
Film Noise Grain
    ↓
Vignette                                      ← Darkens during finishers
```

---

## 🔧 Performance Optimization

| Feature | Technique |
|---------|-----------|
| Rain | BufferGeometry points (no instancing overhead) |
| Enemy HP bars | HTML/CSS overlay, not 3D geometry |
| Bloom | Mipmap blur (one-pass, GPU-efficient) |
| Shadows | Single directional light, 2K shadow map |
| Anti-aliasing | SMAA post-process (no MSAA overhead) |
| Dynamic DPR | AdaptiveDpr — drops to 0.5x on low-end GPUs |
| Physics time step | Slows to ¼ during slow-motion — saves CPU |
| Performance monitor | Auto-drops to medium quality if FPS falls |

---

## 🚀 Expansion Roadmap

### Phase 2 — Content
- [ ] GLTF animated player model (replace capsule)
- [ ] Sword clash particle system
- [ ] Boss arena: Mech Guardian (1000 HP)
- [ ] Parry counter attack animation
- [ ] Combo name display ("DEATH BLOSSOM", "PHANTOM RUSH")

### Phase 3 — Audio
- [ ] Web Audio API integration
- [ ] Positional 3D audio for enemies
- [ ] Dynamic music layers (combat intensity)
- [ ] Blade impact SFX
- [ ] Rain/ambient soundscape

### Phase 4 — Multiplayer (Architecture Ready)
- [ ] Socket.io server (Node.js)
- [ ] Server-authoritative enemy state
- [ ] Client-side prediction for player
- [ ] Co-op 2-player via WebRTC
- [ ] Leaderboard system

### Phase 5 — Advanced Graphics
- [ ] Screen-space reflections on wet surfaces
- [ ] Volumetric light shafts
- [ ] Animated hologram video textures
- [ ] Decal system for slash marks
- [ ] SSAO ambient occlusion

---

## 📦 Key Dependencies

| Package | Purpose |
|---------|---------|
| `@react-three/fiber` | React renderer for Three.js |
| `@react-three/drei` | Helpers: Trail, Sparkles, Environment |
| `@react-three/rapier` | Rapier WASM physics engine |
| `@react-three/postprocessing` | Bloom, chromatic aberration, SMAA |
| `postprocessing` | Underlying effect composer |
| `zustand` | Lightweight reactive global state |
| `three` | 3D engine core |
| `maath` | Math utilities for easing |

---

## 🛠️ Troubleshooting

**Canvas is black / no scene:**
- Check browser console for WebGL errors
- Ensure your GPU supports WebGL 2.0

**Low FPS (<30):**
- Open Settings → set graphicsQuality to 'medium' or 'low'
- Disable depth of field (ultra feature)
- Reduce rain count in gameConfig.js

**Mouse look not working:**
- Click the canvas first to enable pointer lock
- Browser requires user gesture before locking pointer

**Physics acting strange:**
- Rapier WASM loads async — there's a 1-2 second startup delay
- Ensure `@react-three/rapier` version matches peer deps

---

*Project Ronin — Built with React Three Fiber + Rapier + Postprocessing*
*Architecture designed for future multiplayer expansion*

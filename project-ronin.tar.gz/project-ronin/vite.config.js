import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  optimizeDeps: {
    include: ['three','@react-three/fiber','@react-three/drei'],
  },
  build: {
    target: 'esnext',
    rollupOptions: {
      output: {
        manualChunks: {
          three: ['three'],
          r3f: ['@react-three/fiber','@react-three/drei'],
          postprocessing: ['@react-three/postprocessing','postprocessing'],
        }
      }
    }
  }
})
